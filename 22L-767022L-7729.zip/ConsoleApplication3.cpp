#include <iostream>
#include <string>
#include <cmath>
#include <fstream>
#include <sstream>
#include<vector>



using namespace std;

// Function to add two int values and return their sum
int calculatetotal(int a, int b)
{
	int total;
	total = a + b;
	return total;
}

//Class receipt is used to generate receipt and related funtions
class receipt {
protected:
	int quantity;
	int price;
	int total;
	int first, other;
public:
	//Default Constructor...
	receipt()
	{
		quantity = 0;
		price = 0;
		total = 0;
		first = 0;
		other = 0;
	}
	//Function saves data of sale in receipt
	void filereceipt(string name, string cnic, string type, string sk, string desc, int quan, int pri, int tot)
	{
		//Opening Output File
		ofstream outfile("Receipt data.txt", ios::app);
		//Opening Input File
		ifstream infile("SaleID.txt");
		//Opening Another Output file
		ofstream outsale("SaleID.txt", ios::app);
		//Writing information to the file
		outfile << getSalesID() << endl;
		outfile << cnic << endl;
		outfile << name << endl;
		outfile << type << endl;
		outfile << sk << "\t\t" << desc << "\t\t" << quan << "\t\t" << pri << endl;\
		//Closing the output files
		outfile.close();
		outsale.close();
		//Closing the input files
		infile.close();
	}
	//Making a file that keeps history of sales made
	void salehistory(int id, string name, int total, string sk)//sending the information via parameters
	{//Opening Output file
		ofstream outfile("SalesHistory.txt", ios::app);
		//Writing Information to file
		outfile << id << endl;
		outfile << name << endl;
		outfile << total << endl;
		outfile << sk << endl;
		//Closing Output file
		outfile.close();
	}
	//Function to check if the customer has made any sales
	string getsalename(string a)
	{
		//opening input file
		ifstream infile("SalesHistory.txt");
		int id, total;//integers to get value from file
		string name, sku;//strings to get names and sku from file
		while (infile >> id >> name >> total >> sku)//taking input from file till there are entries
		{
			if (name == a)//checking if the name from input file is equal to the one we are trying to find
			{
				infile.close();
				return name;//returning the name if it is found
			}
		}
		//closing output file
		infile.close();
		return ""; // returning a default value if the name is not found
	}
	//Function That takes parameters and is used to print additional items to file
	void filereceiptmultiple(string sk, string desc, int quan, int pri, int tot)
	{
		//opening output file
		ofstream outfile("Receipt data.txt", ios::app);
		//writing data to file
		outfile << sk << "		" << desc << "		" << quan << "		" << pri << endl;
		other = tot;
		outfile << endl;
		//closing output file
		outfile.close();
	}
	//funtion to print total to file
	void printtotalfile(int a, int b)
	{
		int total;
		//calling function that calculates total
		total = calculatetotal(a, b);
		//opening output file
		ofstream outfile("Receipt data.txt", ios::app);
		outfile << total << endl;
		//closing output file
		outfile.close();
	}
	//Function to get SalesID from a file
	int getSalesID()
	{
		//opening input file
		ifstream infile("SaleID.txt");
		if (!infile)//checking if file opens
		{
			cout << "Failed to open file" << endl;
			return 1;
		}

		string last_value;
		string line;
		while (getline(infile, line))//getting input from file
		{
			if (line == "-")//check "-" that is at the end of SaleID file
			{
				// Reached the end of the values before the dash
				break;
			}
			last_value = line;
		}
		//closing Input file
		infile.close();

		int last_value_int = 0;
		if (last_value.empty()) //Checks if there are any values Before "-"
		{
			cout << "No values found before dash" << endl;
		}
		else 
		{
			last_value_int = stoi(last_value);//converting string type value to integer
		}
		return last_value_int;

	}
	// function to increase salesID in SaleID file
	void IncreaseSalesID()
	{
		//opening input file
		ifstream infile("SaleID.txt");
		if (!infile)//checking if file opens
		{
			cout << "Failed to open file" <<endl;
			return;
		}

		string last_value;
		string line;
		string new_line;
		while (getline(infile, line))//taking input from file
		{
			if (line == "-")//checking dash
			{
				// Reached the end of the values before the dash
				break;
			}
			last_value = line;
			new_line += line + "\n";
		}
		//closing input file
		infile.close();

		if (last_value.empty())//checking if there were any values before the dash
		{
			cout << "No values found before dash" << endl;
			return;
		}

		int new_value = stoi(last_value) + 1;//converting the last saleID value from string to integer and increasing it by one
		new_line += to_string(new_value) + "\n-";
		//opening output file
		ofstream outfile("SaleID.txt");
		outfile << new_line;//writing dash to the last line
		//closing output file
		outfile.close();
	}
	//Function that returns total of a sale made
	int gettotal(string a)
	{
		//opening input file
		ifstream infile("SalesHistory.txt");
		int id;
		string name, sku;
		int total;
		//taking input from file
		while (infile >> id >> name >> total>>sku)
		{
			//checking condition
			if (name == a)
			{
				//returning total if condition becomes true
				return total;
			}
		}
		//closing input file
		infile.close();
	}
};
class item
{
protected:
	string item_sku;
	string description;
	int price;
	int quantity;
	int total;
public:
	//default constructor sets values to zero
	item() :price(0), quantity(0), total(0)
	{

	}
	//function to add item to file
	void addItem()
	{
		string item_sku, description;
		double price;
		int quantity;
		// taking input of information from user for the new item
		cout << "+----------------------------------------------------------------+" << endl;
		cout << "Item_SKU: ";
		cin >> item_sku;
		cout << "Description: ";
		cin.ignore(); // ignore newline character in input buffer
		getline(cin, description);
		cout << "Price: ";
		cin >> price;
		cout << "Quantity: ";
		cin >> quantity;
		// opening output file
		ofstream outfile("items.txt", ios::app);
		//writing details of new item to output file 
		outfile << endl;
		outfile << item_sku << "        " << description << "       " << price << "         " << quantity << endl;
		//closing output file
		outfile.close();

		cout << "Item Information successfully saved." << endl;
	}
	//Function Used to remove an item
	void removeItem()
	{
		string item_sku;
		//taking Sku of the item the user wants to delete
		cout << "Enter the SKU of the item you want to remove: ";
		cin >> item_sku;

		// Opening the input file
		ifstream infile("items.txt");
		//checking if input file opens
		if (!infile)
		{
			cout << "Error opening input file." << endl;
			return;
		}
		//using vector for items
		vector<string> items;

		// Read the items from the file
		string line;
		//taking input from file in the loop condition
		while (getline(infile, line))
		{
			//finds spaces in the line
			string sku = line.substr(0, line.find(" "));
			bool sku_found = false;

			// Opening the infput file file
			ifstream salefile("SalesHistory.txt");
			//checking if file opens
			if (!salefile)
			{
				cout << "Error opening SalesHistory file." << endl;
				return;
			}

			// Checks if the SKU is in the SalesHistory file
			string sale_line;
			while (getline(salefile, sale_line))//takes input from file
			{
				string sale_sku = sale_line.substr(sale_line.find_last_of(" ") + 1);
				if (sale_sku == sku)//checks condition
				{
					sku_found = true;
					break;
				}
			}
			//closes file
			salefile.close();

			if (!sku_found && sku != item_sku)
			{
				items.push_back(line); // Add the item to the vector
			}
			else if (sku_found && sku == item_sku)//checks if the item is in sales history
			{
				cout << "The item with SKU " << item_sku << " cannot be removed as it is part of a sale." << endl;
				return;
			}
		}

		// Close the input file
		infile.close();

		// If the item was found and removed
		if (items.size() < items.size() + 1)
		{
			// Open the output file
			ofstream outfile("items.txt");
			if (!outfile)//checks if file opens
			{
				cout << "Error opening output file." << endl;
				return;
			}

			// Write the items back to the file
			for (const auto& item : items)
			{
				outfile << item << endl;
			}

			// Close the output file
			outfile.close();

			cout << "Item with SKU " << item_sku << " successfully removed." << endl;
		}
		else
		{
			cout << "Item with SKU " << item_sku << " not found." << endl;
		}
	}
	//Function that updates details of a item
	void updateItem()
	{
		//opening input file
		ifstream infile("items.txt");
		//opening output file
		ofstream outfile("temp.txt", ios::out);

		string item_sku, description, price, quantity;
		string sku;
		//asking user for sku to check in file
		cout << "Enter the SKU of the item to update: ";
		cin >> sku;
		cin.ignore(); // ignore newline character in input buffer

		bool found = false;
		// taking input from file in the loop condition
		while (infile >> item_sku >> description >> price >> quantity)
		{
			//checks if sku is found
			if (item_sku == sku)
			{
				found = true;
				// shows current details of the item
				cout << "+----------------------------------------------------------------+" << endl;
				cout << "Current details for item with SKU " << sku << ":" << endl;
				cout << "Description: " << description << endl;
				cout << "Price: " << price << endl;
				cout << "Quantity: " << quantity << endl;
				cout << "+----------------------------------------------------------------+" << endl;
				cout << "Enter new details for item with SKU " << sku << ":" << endl;
				//takes new description from file
				cout << "Description (Leave blank to keep the current value): ";
				getline(cin, description);
				//no input then the same description is printed to file
				if (description == "")
				{
					description = description;
				}
				else// does the same for price and quantity
				{
					cout << "Price (Leave blank to keep the current value): ";
					getline(cin, price);

					if (price == "")
					{
						price = price;
					}
					cout << "Quantity (Leave blank to keep the current value): ";
					getline(cin, quantity);

					if (quantity == "")
					{
						quantity = quantity;
					}
				}

				cout << "Item details successfully updated." << endl;
				//Writes data to the file
				outfile << item_sku << "\t\t" << description << "\t\t" << price << "\t\t" << quantity << endl;
			}
			else
			{
				//writes data to file if item was not the one that is trying to be updated
				outfile << item_sku << "\t\t" << description << "\t\t" << price << "\t\t" << quantity << endl;
			}
		}
		//closing input and output files
		infile.close();
		outfile.close();
		//checking bool condition and then replacing the items with temp
		if (found == true)
		{
			// delete the original file and rename the temp file to the original file
			remove("items.txt");
			rename("temp.txt", "items.txt");
			cout << "Item information successfully saved." << endl;
		}
		else
		{
			// delete the temp file
			remove("temp.txt");
			cout << "Item with SKU " << sku << " not found." << endl;
		}
	}
	//Function to search item in a file
	void searchItem()
	{

		string sku, description, dummy;
		double price;
		int quantity;
		//asking the user to input to search the item
		cout << "Please specify at least one of the following to find the item. Leave all fields blank to return to Item Menu:\n";
		cout << "Item_SKU: ";
		getline(cin, dummy);//ignore input buffer
		getline(cin, sku);
		cout << "Description: ";
		getline(cin, description);
		cout << "Price: ";
		string priceStr;
		getline(cin, priceStr);
		if (!priceStr.empty())//checks if nothing is entered
		{
			price = stod(priceStr);//converting string to double if new value is entered

		}
		cout << "Quantity: ";
		string quantityStr;
		getline(cin, quantityStr);//checks if nothing is entered
		if (!quantityStr.empty())
		{

			quantity = stoi(quantityStr);//makes the string the string to int if new value is entered

		}
		bool found = false;
		//opening input file
		ifstream infile("items.txt");


		cout << "+ ---------------------------------------------------------------- +" << endl;
		cout << "Item_SKU Description Price Quantity" << endl;
		cout << "+ ---------------------------------------------------------------- +" << endl;

		//taking input from file
		while (infile >> item_sku >> description >> price >> quantity)
		{
			//checking if either the inputs matches from the entreis in the file
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && (priceStr.empty() || price == price))
			{
				//foung is used as check
				found = true;
				//if input matches then the new information is printed to the file
				cout << item_sku << " " << description << " " << price << " " << quantity << endl;

			}

		}
		//closing input file
		infile.close();


		cout << "+ ---------------------------------------------------------------- +" << endl;
		//checking if item was found
		if (!found)
		{

			cout << "Item not found." << endl;

		}

	}
	//Finds if item is in file by checking the SKU that is taken as parameter
	void showskudetails(string sku)
	{
		string description, dummy;
		double price;
		int quantity;
		bool found = false;
		//opening input file
		ifstream infile("items.txt");


		cout << "+ ---------------------------------------------------------------- +" << endl;
		cout << "Description	Price" << endl;
		cout << "+ ---------------------------------------------------------------- +" << endl;

		//taking input in the loop condition
		while (infile >> item_sku >> description >> price >> quantity)
		{
			//checking if the details match
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{

				found = true;
				//print description and price on console
				cout << description << "		" << price << endl;

			}

		}
		//closes input file
		infile.close();
		cout << "+ ---------------------------------------------------------------- +" << endl;
		//checks if item was found
		if (!found)
		{

			cout << "Item not found." << endl;

		}

	}
	//Function to get quantity from file
	int getquantity(string sku)
	{
		string line, item_sku, description, dummy;
		double price;
		int quantity;
		bool found = false;
		//opening input file
		ifstream infile("items.txt");
		//taking input in the loop condiditon
		while (getline(infile, line))
		{
			stringstream ss(line);
			//using string stream to check inputs from file
			ss >> item_sku >> description >> price >> quantity >> dummy;
			//checming if the SKU matches
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{
				//returns the quantity present in the file
				return quantity;
			}
		}
		//closes input file
		infile.close();
		//checks if item was found in file
		if (!found)
		{
			cout << "Item not found." << endl;
		}
	}
	//Return quantity present in Object
	int returnquantity()
	{
		return quantity;
	}
	//Function used to get description from file using sku
	string getdescription(string sku)
	{
		string line, item_sku, description, dummy;
		double price;
		int quantity;
		bool found = false;
		//opening input file
		ifstream infile("items.txt");
		//taking input in loop condition
		while (getline(infile, line))
		{
			stringstream ss(line);
			//using stringstream to take input from file
			ss >> item_sku >> description >> price >> quantity;
			//checks when sku is found in the file
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{
				//returns description if sku is found
				return description;
			}
		}
		//closes input file
		infile.close();
		//checks if item is found
		if (!found)
		{
			cout << "Item not found." << endl;
		}
	}
	//Function used to get price from the file using sku
	int getprice(string sku)
	{
		//openinf input file
		ifstream infile("items.txt");
		string line;
		//taking input from file in the loop condition
		while (getline(infile, line))
		{
			stringstream ss(line);
			string item_sku, description, dummy;
			double price;
			int quantity;
			//using stringstream to take input from file
			ss >> item_sku >> description >> price >> quantity;
			//checking if the sku matches with entries from file
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{
				//closing input file
				infile.close();
				//returning the price
				return price;
			}
		}
		//closing input file
		infile.close();
	}
	//Checks if sku is in the file
	string findsku(string a)
	{
		string sku;
		string description, dummy;
		double price;
		int quantity;
		bool found = false;
		//opening input file
		ifstream infile("items.txt");
		//taking input from file in loop condition
		while (infile >> item_sku >> description >> price >> quantity)
		{
			//checking if sku is found in the file
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{
				//returns sku as it is 
				found = true;
				return sku;

			}

		}
		//closing input file
		infile.close();
		//checks if sku was found
		if (!found)
		{

			cout << "Item not found." << endl;

		}

	}
	// finds sku but returns bool
	bool findskub(string a)
	{
		string sku;
		string description, dummy;
		double price;
		int quantity;
		bool found = false;
		//opening input file
		ifstream infile("items.txt");
		//taking input from file in the loop condition
		while (infile >> item_sku >> description >> price >> quantity)
		{
			//checking if the sku matches
			if ((sku.empty() || item_sku == sku) && (description.empty() || description == description) && price == price)
			{
				//retursn true if sku is found
				found = true;
				return found;

			}

		}
		//closes input file
		infile.close();
		//checks if item was found
		if (found == false)
		{

			cout << "Item not found." << endl;

		}

	}
	// sets sku of the object
	void setsku(string abc)
	{
		item_sku = abc;
	}
	//returns sku of the object
	string getsku()
	{
		return item_sku;
	}
	//sets description of the object
	void setdescription(string a)
	{
		description = a;
	}
	//sets price of the object
	void setprice(int a)
	{
		price = a;
	}
	//sets quantity of the object
	void setquantity(int a)
	{
		quantity = a;
	}
	//displays price and description of item if it is found in file
	void displaydescprice(string a)
	{
		string check, description_file;
		double price_file;
		int quantity;
		//opens input file
		ifstream infile("items.txt");
		//takes input from file in loop condition
		while (infile >> check >> description_file >> price_file >> quantity)
		{
			//checks if sku is found
			if ((a.empty() || check == a))
			{
				cout << "Description: " << description_file << endl;
				cout << "Price: Rs." << price_file << endl;
			}
		}
		//closes input file
		infile.close();
	}
	//sets total of object
	void settotal(int a)
	{
		total = a;
	}
	//returns total of object
	int returntotal()
	{
		return total;
	}
};
//inherits receipt class
class customer :public receipt
{
protected:
	string cnic;
	string name;
	string email;
	string phone;
	string type;
	receipt R;
public:
	//default constructor for customer
	customer()
	{
		cnic = " ";
		name = " ";
		email = " ";
		phone = " ";
		type = " ";
	}
	//Parameterised constructor for customer
	customer(string c, string n, string e, string p, string t)
	{

		cnic = c;
		name = n;
		email = e;
		phone = p;
		type = t;

	}
	//function that adds a new customer to file
	void addCustomer()
	{
		string dummy;

		//getting information of new item from user
		cout << "+----------------------------------------------------------------+" << endl;
		cout << "CNIC: ";
		getline(cin, dummy);//ignore input buffer
		getline(cin, cnic);
		cout << "Name: ";
		cin.ignore(); // ignore newline character in input buffer
		getline(cin, name);
		cout << "E-mail: ";
		getline(cin, email);
		cout << "Phone Number: ";
		getline(cin, phone);
		cout << "Membership Type: ";
		getline(cin, type);

		//opens output file
		ofstream outfile("customers.txt", ios::app);
		//writes the new information to the file
		outfile << endl << cnic << "        " << name << "          " << email << "         " << phone << "         " << type;
		//closes output file
		outfile.close();

		cout << "Customer Information successfully saved." << endl;

	}
	// sets cnic of the object
	void setcnic()
	{
		getline(cin, cnic);
	}
	//updates the customer details
	void updateCustomer()
	{

		string customer_cnic;
		cout << "Enter the CNIC of the customer to update: ";
		cin.ignore();//ignore input buffer
		getline(cin, customer_cnic);
		bool found = false;
		//opening input and outpur files
		ifstream infile("customers.txt");
		ofstream outfile("temp.txt", ios::out);

		string cnic, name, email, phone, type;
		//taking input from file in the loop condition
		while (getline(infile, cnic, '\t') && getline(infile, name, '\t') && getline(infile, email, '\t') && getline(infile, phone, '\t') && getline(infile, type))
		{
			//checks if cnic is found in the file
			if (customer_cnic == cnic)
			{
				found = true;

				//shows current details of the customer
				cout << "+----------------------------------------------------------------+" << endl;
				cout << "Current details for the customer with CNIC: " << cnic << ":" << endl;
				cout << "Name: " << name << endl;
				cout << "E-mail: " << email << endl;
				cout << "Phone Number: " << phone << endl;
				cout << "Membership Type: " << type << endl;
				cout << "+----------------------------------------------------------------+" << endl;

				//asks for new detials
				cout << "Enter new details for customer with CNIC: " << cnic << ":" << endl;
				cout << "Name: ";
				cin.ignore();
				getline(cin, name);
				cout << "E-mail: ";
				getline(cin, email);
				cout << "Phone Number: ";
				getline(cin, phone);
				cout << "Membership Type: ";
				getline(cin, type);
				cout << "Customer details successfully updated." << endl;

			}
			//writes new details to the file
			outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;

		}
		//closes both input and output file
		infile.close();
		outfile.close();
		//repalces and renames file with temp
		if (found)
		{

			// delete the original file and rename the temp file to the original file
			remove("customers.txt");
			rename("temp.txt", "customers.txt");

		}
		else
		{

			// delete the temp file
			remove("temp.txt");
			cout << "Customer with CNIC: " << customer_cnic << " was not found." << endl;

		}
	}
	// function to check if the customer is in the file
	void findCustomer()
	{

		string cnic, name, email, phone, type, dummy;
		string cnic_file, name_file, email_file, phone_file, type_file;
		bool found = false;
		//opening input file
		ifstream infile("customers.txt");


		cout << "Please specify at least one of the following to find the customer." << endl;
		cout << "Leave all fields blank to return to Customers Menu:" << endl;

		cout << "CNIC: ";
		getline(cin, dummy);//ignore input buffer
		getline(cin, cnic);
		cout << "Name: ";
		getline(cin, name);
		cout << "Email: ";
		getline(cin, email);
		cout << "Phone: ";
		getline(cin, phone);
		cout << "Type: ";
		getline(cin, type);
		//taking input from file in the loop condidtion
		while (infile >> cnic_file >> name_file >> email_file >> phone_file >> type_file)
		{
			//checks if any of the entered details are found
			if ((cnic.empty() || cnic == cnic_file) && (name.empty() || name == name_file) && (email.empty() || email == email_file) && (phone.empty() || phone == phone_file) && (type.empty() || type == type_file))
			{
				if (!found)
				{
					cout << "+----------------------------------------------------------------+" << endl;
					cout << "CNIC\t\tName\t\tEmail\t\t\tPhone Number\tMembership" << endl;
					cout << "+----------------------------------------------------------------+" << endl;
				}
				found = true;
				//prints the details of the customer if found
				cout << cnic_file << "\t" << name_file << "\t" << email_file << "\t\t" << phone_file << "\t\t" << type_file << endl;
			}
		}

		cout << "+----------------------------------------------------------------+" << endl;
		//closes input file
		infile.close();
		//checks if customer was found
		if (!found)
		{
			cout << "No customer found with the given criteria." << endl;
		}
	}
	//function that deletes a customer from the file
	void deleteCustomer()
	{
		string customer_cnic;
		cout << "Enter the CNIC of the customer to delete: ";
		cin.ignore();
		getline(cin, customer_cnic);

		bool found = false;
		//opening input and output files
		ifstream infile("customers.txt");
		ofstream outfile("temp.txt");

		string cnic, name, email, phone, type;
		//taking input from input file inside the loop condition
		while (infile >> cnic >> name >> email >> phone >> type)
		{
			//checks is cnic is found
			if (customer_cnic == cnic)
			{
				found = true;
				//shows current details of the customer
				cout << "+----------------------------------------------------------------+" << endl;
				cout << "Details for the customer with CNIC: " << cnic << ":" << endl;
				cout << "Name: " << name << endl;
				cout << "E-mail: " << email << endl;
				cout << "Phone Number: " << phone << endl;
				cout << "Membership Type: " << type << endl;
				cout << "+----------------------------------------------------------------+" << endl;

				// Checks if the customer's name is in the SalesHistory file
				ifstream salefile("SalesHistory.txt");//opening salehistory input file
				string sale_line;
				bool name_found = false;
				int id, total;
				string sale_name, sku;
				//taking input from salehistory file inside loop condition
				while (salefile >> id >> sale_name >> total >> sku)
				{
					//checks if name is found in sales history
					if (sale_name == R.getsalename(name))
					{
						name_found = true;
						break;
					}
				}
				//closes salesghistory file
				salefile.close();
				//checks if name was found in the salehistory file
				if (name_found == true)
				{
					outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
					cout << "Customer with CNIC: " << cnic << " has not been deleted because their name is in the SalesHistory file." << endl;
				}
				else//deletes the customer if the customer is not found in sale history 
				{
					//asks user if he wants to delete the customer
					cout << "Do you want to delete this customer? (y/n): ";
					string choice;
					getline(cin, choice);
					if (choice == "y")
					{
						cout << "Customer with CNIC: " << cnic << " has been deleted." << endl;
					}
					else
					{
						//if user enters no then the information is not deleted
						outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
						cout << "Customer with CNIC: " << cnic << " has not been deleted." << endl;
					}
				}
			}
			else
			{
				//writes output to the customers file
				outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
			}
		}
		//closes input and output files
		infile.close();
		outfile.close();
		
		if (found == true)
		{
			// delete the original file and rename the temp file to the original file
			remove("customers.txt");
			rename("temp.txt", "customers.txt");
		}
		else
		{
			// delete the temp file
			remove("temp.txt");
			cout << "Customer with CNIC: " << customer_cnic << " was not found." << endl;
		}
	}
	//checks if customer is there by finding cnic
	bool findcnic(string a)
	{
		bool check = false;
		string cnic_file, name_file, email_file, phone_file, type_file;
		bool found = false;
		// opening input file
		ifstream infile("customers.txt");
		//taking input from file in loop condition
		while (infile >> cnic_file >> name_file >> email_file >> phone_file >> type_file)
		{
			//checks is cnic is found or not 
			if ((cnic.empty() || a == cnic_file))
			{
				cnic = cnic_file;
				name = name_file;
				type = type_file;
				found = true;
				check = true;
			}
		}
		//closes input file
		infile.close();
		//checks if person was not found
		if (!found)
		{
			cout << "No customer found with the given cnic." << endl;
		}
		//returns true if person was found
		return check;
	}
	//returns cnic of object
	string getcnic()
	{
		return cnic;
	}
	//returns name of object
	string getname()
	{
		return name;
	}
	//returns type of object
	string gettype()
	{
		return type;
	}
	// Getters
	//Returns the email of object
	string getEmail() const
	{
		return email;
	}
	//returns phone of object
	string getPhone() const
	{
		return phone;
	}
	// Setters
	//sets cnic of object
	void setCnic(const string& cnic)
	{
		this->cnic = cnic;
	}
	//sets name in object
	void setName(const string& name)
	{
		this->name = name;
	}
	//sets emial in object
	void setEmail(const string& email)
	{
		this->email = email;
	}
	//sets phone in object
	void setPhone(const string& phone)
	{
		this->phone = phone;
	}
	//sets type in object
	void setType(const string& type)
	{
		this->type = type;
	}
	// Overloaded input operator to read a Customer object from a stream
	friend istream& operator>>(istream& in, customer& c);
	friend ostream& operator<<(ostream& out, const customer& c);
};
//silver custom class
class SilverCustomer :public customer
{
protected:
	int saleslimitsilver;
public:
	//silver customer cunstructor
	SilverCustomer()
	{
		saleslimitsilver = 40000;
	}
	//writing data in silver customers file
	void silvercustomersdata()
	{
		//opening input file
		ifstream infile("customers.txt");
		//opening output file
		ofstream outfile("Silver Customers list.txt");
		string check = "Silver";
		string line, cnic, name, email, phone, type;
		//reading data from file
		while (getline(infile, line))
		{
			//using string stream towork on strings
			stringstream ss(line);
			if (ss >> cnic >> name >> email >> phone >> type)
			{
				if (type == check)
				{
					//writing data in output fiile
					outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
				}
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//writing sales done to silver customers
	void silvercustomerssales()
	{
		//opening input file
		ifstream infile("Silver Customers list.txt");
		//opening output file
		ofstream outfile("Silver Customers Sales.txt");
		string line, cnic, name, email, phone, type;
		while (getline(infile, line))
		{
			//using string stream to work on strings
			stringstream ss(line);
			//reading input from file
			ss >> cnic >> name >> email >> phone >> type;
			//writing output in file
			outfile << name << endl;
			outfile << saleslimitsilver << endl;
			outfile << endl;
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//updating data in silver sales file
	void silversales()
	{
		//opening input file
		ifstream infile("Silver Customers Sales.txt");
		//opening output file
		ofstream outfile("Silver Sales.txt");
		string name;
		int limit, zero = 0;
		//reading till end of file
		while (!infile.eof())
		{
			//reading from input file
			infile >> name >> limit;
			//writing in output file
			outfile << name << endl;
			outfile << limit << endl;
			outfile << zero << endl;
		}
		cout << "Silver Sales outfile updated." << endl;
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//checking if customer is a silver customer
	bool checksilvercustomer(string a)
	{
		// opening input file
		ifstream infile("Silver Customers Sales.txt");
		string line;
		bool check = false;
		// reading from input file
		while (!infile.eof())
		{
			getline(infile, line);
			stringstream ss(line);
			string name;
			int limit;
			ss >> name >> limit;
			// applying the check
			if (name == a)
			{
				check = true;
				break;
			}
		}
		// closing input file
		infile.close();
		return check;
	}

	//getting transaction limit of silver customer
	int getlimitsilver(string a)
	{
		//opening input file
		ifstream infile("Silver Sales.txt");
		string name;
		int limit;
		int used;
		//reading data from file
		if (!infile)
		{
			cout << "File NOT OPEN" << endl;
		}
		while (!infile.eof())
		{
			infile >> name >> limit >> used;
			//checking name
			if (name == a)
			{
				infile.close();
				return limit;
			}
		}
		//closing iinput file
		infile.close();
		//return -1; // return -1 if name is not found
	}
	//updating data of silver customer
	void updatesalessilver(int used, string a)
	{
		string name;
		int limit, remaining;
		//opening input file
		ifstream infile("Silver Sales.txt");
		//opening output file
		ofstream outfile("temp.txt");
		//reading data from file
		while (infile >> name >> limit >> remaining)
		{
			if (name == a)
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << used << endl;
			}
			else
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << remaining << endl;
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
		//removing unnecessary file
		remove("Silver Sales.txt");
		//renaming the file
		rename("temp.txt", "Silver Sales.txt");
	}
};
//gold customer class
class GoldCustomer : public customer
{
protected:
	int saleslimitgold;

public:
	//gold customer cunstructor
	GoldCustomer()
	{
		saleslimitgold = 100000;
	}
	//inputting data in gold customers file
	void goldcustomersdata()
	{
		//opening input file
		ifstream infile("customers.txt");
		//opening output file
		ofstream outfile("Gold Customers list.txt");
		string check = "Gold";
		string line, cnic, name, email, phone, type;
		//reading the input file for gold customers
		while (getline(infile, line))
		{
			stringstream ss(line);
			if (ss >> cnic >> name >> email >> phone >> type)
			{
				if (type == check)
				{
					//writing in output file
					outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
				}
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//input data in file of gold sales
	void goldsales()
	{
		//opening input file
		ifstream infile("Gold Customers Sales.txt");
		//opening output file
		ofstream outfile("Gold Sales.txt");
		string name;
		int limit, zero = 0;
		while (!infile.eof())
		{
			//reading from input file
			infile >> name >> limit;
			//writing in output file
			outfile << name << endl;
			outfile << limit << endl;
			outfile << zero << endl;
		}
		cout << "Gold Sales outfile updated." << endl;
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//writing file 
	void goldcustomerssales()
	{
		//opening input file
		ifstream infile("Gold Customers list.txt");
		//opening output file
		ofstream outfile("Gold Customers Sales.txt");
		string line, cnic, name, email, phone, type;
		while (getline(infile, line))
		{
			//using string stream to work on strings
			stringstream ss(line);
			ss >> cnic >> name >> email >> phone >> type;
			//writing in file
			outfile << name << endl;
			outfile << saleslimitgold << endl;
			outfile << endl;
		}
		infile.close();
		outfile.close();
	}
	//checks if customer is gold type or not
	bool checkgoldcustomer(string a)
	{
		//opening input file
		ifstream infile("gold Customers Sales.txt");
		string name;
		int limit;
		bool check = 0;
		while (infile >> name >> limit)
		{
			//searching in file
			if (name == a)
			{
				cout << name;
				check = 1;
				return check;
			}
		}
		//closing input file
		infile.close();
		return check;
	}
	//check limit of transaction for gold customer
	int getlimitGold(string a)
	{
		//opening input file
		ifstream infile("Gold Sales.txt");
		string name;
		int limit;
		int used;
		while (!infile.eof())
		{
			//reading the file
			infile >> name >> limit >> used;
			//searching the limit for a customer
			if (name == a)
			{
				infile.close();
				return limit;
			}
		}
		//closing input file
		infile.close();
		return -1; // return -1 if name is not found
	}
	//telling the amount of transaction used
	void updatesalesgold(int used, string a)
	{
		string name;
		int limit, remaining;
		//opening input file
		ifstream infile("Gold Sales.txt");
		//opening output file
		ofstream outfile("temp.txt");
		while (infile >> name >> limit >> remaining)
		{
			//checking in input file
			if (name == a)
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << used << endl;
			}
			else
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << remaining << endl;
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
		//removing extra files
		remove("Gold Sales.txt");
		//renaming file
		rename("temp.txt", "Gold Sales.txt");
	}
	int calculatediscountgold(int discount, int to_pay) 
	{
		// Calculate the discount amount

		int final_amount = to_pay - (to_pay*discount/100);

		// Return the final amount to be paid
		return final_amount;
	}
};
//platinum customers class
class PlatinumCustomer : public customer
{
protected:
	int saleslimitplatinum;

public:
	//platinum customer cunstructor
	PlatinumCustomer()
	{
		saleslimitplatinum = 100000;
	}
	//writing data for platinum customers
	void platinumcustomersdata()
	{
		//opeening input file
		ifstream infile("customers.txt");
		//opening output file
		ofstream outfile("Platinum Customers list.txt");
		string check = "Platinum";
		string line, cnic, name, email, phone, type;
		while (getline(infile, line))
		{
			//using string stream to work with strings
			stringstream ss(line);
			if (ss >> cnic >> name >> email >> phone >> type)
			{
				//checking type of customer
				if (type == check)
				{
					//writing in file
					outfile << cnic << "\t" << name << "\t" << email << "\t" << phone << "\t" << type << endl;
				}
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//checking sales of platinum customers
	void platinumcustomerssales()
	{
		//opening input file
		ifstream infile("Platinum Customers list.txt");
		//opening output file
		ofstream outfile("Platinum Customers Sales.txt");
		string line, cnic, name, email, phone, type;
		while (getline(infile, line))
		{
			//using string stream to work on strings
			stringstream ss(line);
			//geting input
			ss >> cnic >> name >> email >> phone >> type;
			//writing in file
			outfile << name << endl;
			outfile << saleslimitplatinum << endl;
			outfile << endl;
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//checking if customer is platinum customer
	bool checkplatinumcustomer(string a)
	{
		//opening input file
		ifstream infile("Platinum Customers Sales.txt");
		string name;
		int limit;
		bool check = 0;
		//reading from file
		while (infile >> name >> limit)
		{
			//checking for platinum customer
			if (name == a)
			{
				check = 1;
				return check;
			}
		}
		//closing input file
		infile.close();
		return check;
	}
	//updating sales file of platinum customer
	void platinumsales()
	{
		//opening input file
		ifstream infile("Platinum Customers Sales.txt");
		//opening output file
		ofstream outfile("Platinum Sales.txt");
		string name;
		int limit, zero = 0;
		while (!infile.eof())
		{
			//reading data from input file
			infile >> name >> limit;
			//writing data in output file
			outfile << name << endl;
			outfile << limit << endl;
			outfile << zero << endl;
		}
		cout << "Platinum Sales outfile updated." << endl;
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
	}
	//getting limit of transaction of platinum customer
	int getlimitplatinum(string a)
	{
		//opening input file
		ifstream infile("Platinum Sales.txt");
		string name;
		int limit;
		int used;
		//reading data from file
		while (infile >> name >> limit >> used)
		{
			//checking the limits
			if (name == a)
			{
				infile.close();
				return limit;
			}
		}
		//closing input file
		infile.close();
		return -1; // return -1 if name is not found
	}
	//updating platinum sale file
	void updatesalesplatinum(int used, string a)
	{
		string name;
		int limit, remaining;
		//opening input file
		ifstream infile("Platinum Sales.txt");
		//opening output file
		ofstream outfile("temp.txt");
		//reading inpute file data
		while (infile >> name >> limit >> remaining)
		{
			if (name == a)
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << used << endl;
			}
			else
			{
				//writing in output file
				outfile << name << endl;
				outfile << limit << endl;
				outfile << remaining << endl;
			}
		}
		//closing input file
		infile.close();
		//closing output file
		outfile.close();
		//removing unnecessary file
		remove("Platinum Sales.txt");
		//renaming file
		rename("temp.txt", "Platinum Sales.txt");
	}
	int calculatediscountplatinum(int discount, int to_pay)
	{
		// Calculate the discount amount

		int final_amount = to_pay - (to_pay * discount / 100);

		// Return the final amount to be paid
		return final_amount;
	}
};

class Sales :public item, customer, receipt
{
protected:

	customer A;
	item B;
	string customer_cnic;
	string customer_name;
	string customer_tyoe;
	int total, newtotal, counter;
	receipt C;
	item D, E;
	item* print = new item[100];
	int count = 0;
public:
	//Default constructor
	Sales()
	{
		newtotal = 0;
		total = 0;
		counter = 0;
	}
	//parameterised constructor
	Sales(int a)
	{
		total = 0;
		newtotal = 0;
		counter = 0;
	}
	//function to make a sale
	void makenewsales(int x)
	{
		//checks if x=0 or not 
		if (x == 0)
		{
			int quan;
			int itemquan;
			int _total;
			int wholetotal[3];
			string customercnic;
			string item_sku;
			//outputs saleif
			cout << "Sales ID: " << C.getSalesID() << endl;
			cout << "Enter CNIC: ";
			cin.ignore();
			getline(cin, customercnic);
			//finds cnic in file using function
			if (A.findcnic(customercnic))
			{
				//sets customer_cnic
				customer_cnic = A.getcnic();
				cout << "Enter the SKU of the item you want to add: ";
				//takes input of sku from user 
				getline(cin, item_sku);
				//checks if sku is in file
				if (B.findskub(item_sku) == true)
				{
					//setting object sku
					B.setsku(item_sku);
					//displaying information of the sku
					B.displaydescprice(item_sku);
					cout << "Enter The Quantity: ";
					//takes input of quantity
					cin >> quan;
					if (quan <= 0)
					{
						cout << "The entered quantity is incorrect";
					}
					else
					{
						itemquan = B.getquantity(item_sku);
						//checks if quantity entered is greater than quantity in file
						if (quan > itemquan)
						{
							cout << "The Requested Quantity is greater than the available stock." << endl;
							cout << "The available stock is: " << itemquan;
						}
						else
						{
							//sets quantity of object
							B.setquantity(quan);
							//calculates total
							_total = quan * B.getprice(item_sku);
							total = _total;
							itemquan = itemquan - quan;
							cout << "Sub Total : " << _total << endl;
						}
					}
				}
				else
				{
					cout << "Entered Item Sku is incorrect" << endl;
				}
			}
			count = 0;
		}//calls removesale item if x=3 that is taken as parameter
		else if (x == 3)
		{
			removesaleitem();
		}
	}
	//function that adds a new item to the sale
	void addnewitem(int a)
	{
		//works only when a=1
		if (a == 1)
		{
			int quan;
			int itemquan;
			int _total = 0;
			int _newtotal = 0;
			string item_sku, checking;
			//asks user for sku
			cout << "Enter the SKU of the item you want to add: ";

			cin.ignore();
			getline(cin, item_sku);
			checking = D.findsku(item_sku);
			//checks if item with entered sku exists
			if (D.findskub(item_sku))
			{
				//sets sku of object
				D.setsku(item_sku);
				//displays description and price 
				D.displaydescprice(item_sku);

				cout << "Enter the quantity: ";
				cin >> quan;
				//checks if correct quantity is entered 
				if (quan <= 0)
				{
					cout << "The entered quantity is incorrect";
				}
				else
				{
					//gets quantity from file
					itemquan = D.getquantity(item_sku);
					// checks if quantity does exceed available quantity
					if (quan > itemquan)
					{
						cout << "The requested quantity is greater than the available stock." << endl;
						cout << "The available stock is: " << itemquan;
					}
					else
					{
						//sets quantity of object
						D.setquantity(quan);
						//calculates total and sets it in the object
						_newtotal = quan * D.getprice(item_sku);
						D.settotal(_newtotal);
						//displays total of the new item
						cout << "Sub Total: " << _newtotal << endl;
						E.setsku(D.getsku());
						E.setquantity(quan);
						E.settotal(_newtotal);
						newtotal += _newtotal;
					}
					//stores object E in Object array
					print[count] = E;
					count++;
				}
			}
			else
			{
				cout << "Entered Item Sku is incorrect." << endl;
			}
		}
	}
	//shows the information of the items in the sale
	void printdata(int a)
	{

		if (a == 2)
		{
			//displays the information of the items using functions
			cout << "Sales ID: " << C.getSalesID() << "\t\t" << "CNIC: " << customer_cnic << endl;
			cout << "Name: " << A.getname() << "\t\t" << "Type: " << A.gettype() << endl;
			cout << "+ ------------------------------------------------------------- +" << endl;
			cout << "	Item_SKU	Description		 Quantity	Amount" << endl;
			cout << "+ ------------------------------------------------------------- +" << endl;
			cout << "	" << B.getsku() << "\t" << B.getdescription(B.getsku()) << "\t\t\t" << B.returnquantity() << "\t" << "Rs." << total << endl;
			//writes the details in the file using function
			C.filereceipt(A.getname(), A.getcnic(), A.gettype(), B.getsku(), B.getdescription(""), B.returnquantity(), B.getprice(B.getsku()), total);
			//checks if more than one item was added
			if (newtotal != 0)
			{
				//prints all the remaining items if any were added and sends them to the receipt class to print in file
				for (int b = 0; b < count; b++)
				{
					cout << "	" << print[b].getsku() << "\t" << print[b].getdescription(print[b].getsku()) << "\t\t\t" << print[b].returnquantity() << "\t\t" << "Rs." << print[b].returntotal() << endl;
					C.filereceiptmultiple(print[b].getsku(), print[b].getdescription(print[b].getsku()), print[b].returnquantity(), print[b].getprice(print[b].getsku()), newtotal);
				}
			}

			cout << "+ ------------------------------------------------------------- +" << endl;
			cout << " Total: " << "Rs." << total + newtotal << endl;
			C.printtotalfile(total, newtotal);
			//inputs sale made in sale history file
			C.salehistory(C.getSalesID(), A.getname(), calculatetotal(total, newtotal), B.getsku());
			cout << "+ ------------------------------------------------------------- +" << endl;
			//increases saleID
			C.IncreaseSalesID();
			counter = count;

		}
	}
	//removes an item from the sale
	void removesaleitem()
	{
		string item_sku;
		//gets sku of item to be removed from the user
		cout << "Enter SKU of item to remove: ";
		cin >> item_sku;

		// Check if item is in sale
		if (B.getsku() == item_sku)
		{
			// Item to be removed is the first item in sale
			total = 0;
			int item_quantity = B.getquantity(item_sku);
			B.setquantity(0);
			B.setsku("");
			B.setdescription("REMOVEDITEM");
			cout << "Item with SKU " << item_sku << " removed from sale." << endl;
			return;
		}

		bool found = false;
		// Check if item to be removed is in the additional items list
		for (int i = 0; i < count; i++)
		{
			if (print[i].getsku() == item_sku)
			{
				found = true;
				newtotal -= print[i].returntotal();
				// Remove item from the additional items list
				for (int j = i; j < count - 1; j++)
				{
					print[j] = print[j + 1];
				}
				count--;
				break;
			}
		}

		// Check if item to be removed is in the make new sale items list
		if (!found)
		{
			for (int i = 0; i < count; i++)
			{
				//checks if item is found
				if (print[i].getsku() == item_sku)
				{
					found = true;
					newtotal -= print[i].returntotal();
					// Remove item from the make new sale items list
					for (int j = i; j < count - 1; j++)
					{
						print[j] = print[j + 1];
					}
					count--;
					break;
				}
			}
		}
		if (!found)
		{
			// Item to be removed is not in sale
			cout << "Item with SKU " << item_sku << " not found in sale." << endl;
			return;
		}
		cout << "Item with SKU " << item_sku << " removed from sale." << endl;
		return;
	}
	//discards the current ongoing sale
	void cancelsale(int a)
	{
		if (a == 4)
		{
			cout << "The current Sale has succesfully been cancelled." << endl;
			return;
		}
	}
	//deletes the array of objects
	~Sales()
	{
		delete[]print;
	}
};

class payment :public receipt, SilverCustomer, GoldCustomer, PlatinumCustomer
{
protected:
	SilverCustomer S;
	GoldCustomer TopG;
	PlatinumCustomer P;
	receipt R;
public:
	//function used to make payment
	void makepayment(int a)
	{
		int id;
		int total;
		int paid, remaining = 0;
		int to_pay;
		string name,sku;
		bool check = false;
		bool goldcheck = false;
		bool platinumcheck = false;
		int discount = 0;
		//opens input file
		ifstream infile("SalesHistory.txt");
		//takes input from file in while condition
		while (infile >> id >> name >> total>>sku)
		{
			//checks if saleid is found
			if (id == a)
			{
				cout << "SaleID : " << a << endl;
				cout << "Customer Name : " << name << endl;
				//checks if the customer is a silver customer
				if (S.checksilvercustomer(name)==true)
				{
					
					//displays the total limit of a silver customer using function
					cout << "Total Sales Amount: " << S.getlimitsilver(name) << endl;
					remaining = S.getlimitsilver(name);
					check = true;
					paid = R.gettotal(name);
					cout << "Amount Paid: " << paid << endl;
					//calculates the amount remaining to be paid
					cout << "Remaining Amount: " << remaining - paid << endl;
					cout << "Amount to be paid: ";
					cin >> to_pay;
					double balance;
					balance = remaining - paid;
					//checks if the customer has enough balance to pay the amount
					if (to_pay > balance)
					{
						cout << "insufficient balance" << endl;
						return;
					}
					else if (to_pay <= balance)
					{
						cout << "Payment Succesful." << endl;
						S.updatesalessilver(to_pay, name);
					}
				}//checks if the customer is a gold customer
				else if (TopG.checkgoldcustomer(name)==true)
				{
					//gets limit of gold customer
					cout << "Total Sales Amount: " << TopG.getlimitGold(name) << endl;
					remaining = TopG.getlimitGold(name);
					goldcheck = true;
					paid = R.gettotal(name);
					cout << "Amount Paid: " << paid << endl;
					//calculates the remaining balance of the customer
					cout << "Remaining Amount: " << remaining - paid << endl;
					cout << "Amount to be paid: ";
					cin >> to_pay;
				}//checks if the customer is a platinum customer
				else if (P.checkplatinumcustomer(name))
				{
					//gets  the limit of the customer
					cout << "Total Sales Amount: " << P.getlimitplatinum(name) << endl;
					remaining = P.getlimitplatinum(name);
					platinumcheck = true;
					check = true;
					paid = R.gettotal(name);
					cout << "Amount Paid: " << paid << endl;
					//calculates the remaining amount of the customer
					cout << "Remaining Amount: " << remaining - paid << endl;
					cout << "Amount to be paid: ";
					cin >> to_pay;

				}
				//runs for gold customer
				if (goldcheck)
				{
					cout << "The Customer is a Gold Customer and can have a discount of up to 3%." << endl;
					cout << "Input the discount % for the customer : ";
					cin >> discount;
					//checks if current percentage of discount is entered 
					if (discount > 3 || discount < 0)
					{
						cout << "The Entered Discount percentage can't be offered" << endl;
					}
					else if (discount > 0)//calculates discount
					{
							to_pay = TopG.calculatediscountgold(discount, to_pay);
						cout << "Payable Amount is: " << to_pay << endl;
					}
				}//runs for platinum customer
				if (platinumcheck)
				{
					//asks for dicount percentage
					cout << "The Customer is a Platinum Customer and can have a discount of up to 5%." << endl;
					cout << "Input the discount % for the customer : ";
					cin >> discount;
					//checks if current amount of discount is entered
					if (discount > 5 || discount < 0)
					{
						cout << "The Entered Discount percentage can't be offered" << endl;
					}
					else if (discount > 0)
					{
						//calculates the value after the discount and shows it to user
							to_pay = P.calculatediscountplatinum(discount, to_pay);
						cout << "Payable Amount is: " << to_pay << endl;
					}
					if (to_pay > remaining - paid)
					{
						cout << "Insufficient Balance." << endl;
						return;
					}
					else
					{
						cout << "Payment Successful." << endl;
						if (check == true)
						{
							S.updatesalessilver(to_pay + paid, name);
						}
						else if (goldcheck == true)
						{
							TopG.updatesalesgold(to_pay + paid, name);
						}
						else if (platinumcheck == true)
						{
							P.updatesalesplatinum(to_pay + paid, name);
						}
						else
							return;
					}
				}
			}
		}
		if (!check)
		{
			cout << "No record found for Sale ID: " << a << endl;
		}
		infile.close();
	}
};
void displayMainMenu()
{

	cout << "1. Manage Items" << endl;
	cout << "2. Manage Customers" << endl;
	cout << "3. Make New Sale" << endl;
	cout << "4. Make Payment" << endl;
	cout << "5. Exit" << endl;
	cout << "(Press 1 to 5 to select an option)" << endl;

}
void displayItemsMenu()
{

	cout << "1. Add new Item" << endl;
	cout << "2. Update Item details" << endl;
	cout << "3. Find Items" << endl;
	cout << "4. Remove Existing Item" << endl;
	cout << "5. Return to Main Menu" << endl;
	cout << "(Press 1 to 5 to select an option)" << endl;

}
void displayCustomersMenu()
{

	cout << "1. Add new Customer" << endl;
	cout << "2. Update Customer details" << endl;
	cout << "3. Find Customer" << endl;
	cout << "4. Remove Existing Customer" << endl;
	cout << "5. Return to Main Menu" << endl;
	cout << "(Press 1 to 5 to select an option)" << endl;

}
int main()
{
	item a;
	customer b;
	Sales c;
	int choice;
	SilverCustomer silvercheck;
	GoldCustomer goldcheck;
	PlatinumCustomer platinumcheck;
	payment	P;
	Sales test;
	int x = 0;

	do
	{
		displayMainMenu();
		int count = 0;
		cin >> choice;
		x = 0;
		switch (choice)
		{
		case 1:
		{
			int choice2;
			do
			{

				displayItemsMenu();
				cin >> choice2;
				switch (choice2)
				{
				case 1:
					a.addItem();
					break;
				case 2:
					a.updateItem();
					break;
				case 3:
					a.searchItem();
					break;
				case 4:
					a.removeItem();

					break;
				case 5:
					break;
				default:
					cout << "Invalid choice. Please try again." << endl;
				}
			} while (choice2 != 5);
			break;
		}
		case 2:
		{
			int choice3;
			do
			{
				displayCustomersMenu();
				cin >> choice3;
				switch (choice3)
				{
				case 1:
					b.addCustomer();
					break;
				case 2:
					b.updateCustomer();
					break;
				case 3:
					b.findCustomer();
					break;
				case 4:
					b.deleteCustomer();
					break;
				case 5:
					break;
				default:
					cout << "Invalid choice. Please try again." << endl;
				}
			} while (choice3 != 5);
			break;
		}
		case 3:
			test.makenewsales(x);
			do
			{
				cout << "Press 1 to Enter New Item." << endl;
				cout << "Press 2 to End Sale." << endl;
				cout << "Press 3 to remove an item from current sale." << endl;
				cout << "Press 4 to Cancel Sale" << endl;
				cin >> x;
				if (x == 1)
				{
					count++;
				}
				test.addnewitem(x);
				test.printdata(x);
				test.makenewsales(x);
				test.cancelsale(x);
			} while (x != 2 && x != 4);
			break;
		case 4:
			int id;
			cout << "Enter SaleID: ";
			cin >> id;
			P.makepayment(id);
			break;
		case 5:
			cout << "Exiting program..." << endl;
			break;
		default:
			cout << "Invalid choice. Please try again." << endl;
		}
	} while (choice != 5);

	return 0;
}